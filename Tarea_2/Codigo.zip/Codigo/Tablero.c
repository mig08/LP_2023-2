#include "Tierra.h"
#include "Tablero.h"
#include "Bomba.h"

void IniciarTablero(int n){
    // Su codigo
    return;
}


void PasarTurno(){
    // Su codigo
    return;
}


void ColocarBomba(Bomba* b, int fila, int columna){
    // Su codigo
    return;
}


void MostrarTablero(){
    // Su codigo
    return;
}


void MostrarBombas(){
    // Su codigo
    return;
}


void VerTesoros(){
    // Su codigo
    return;
}


void BorrarTablero(){
    // Su codigo
    return;
}