#include "Tierra.h"
#include "Tablero.h"
#include "Bomba.h"

void TryExplotar(int fila, int columna){
    // Su codigo
    return;
}

void BorrarBomba(int fila, int columna){
    // Su codigo
    return;
}

void ExplosionPunto(int fila, int columna){
    // Su codigo
    return;
}

void ExplosionX(int fila, int columna){
    // Su codigo
    return;
}
