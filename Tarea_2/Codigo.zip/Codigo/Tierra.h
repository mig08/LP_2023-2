#ifndef TIERRA_H
#define TIERRA_H

typedef struct Tierra{
    int vida;
    int es_tesoro;
} Tierra;

#endif