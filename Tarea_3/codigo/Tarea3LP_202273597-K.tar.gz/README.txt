Nombre: Martin Ibañez
Rol: 202273597-K
Instrucciones: Para utilizar el programa es necesario que esten en la misma carpeta: Pikinim.java, Cyan.java, Magenta.java, Amarillo.java, Zona.java, Pieza.java, 
Enemigo.java, Pildora.java, Muralla.java, Juego.java, ILevantable.java.
Luego compilarlo con el Makefile. 
Se probó en Windows 10 y compilando con javac 11.0.20.1

